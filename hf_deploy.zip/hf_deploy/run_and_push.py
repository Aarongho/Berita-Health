"""
run_and_push.py
---------------
1. Jalankan scraper (health_scraper_final.py)
2. Simpan hasil ke CSV
3. Push CSV ke Hugging Face Datasets

Dijalankan otomatis oleh GitHub Actions sesuai jadwal.
"""

import os
import sys
from pathlib import Path
from datetime import datetime, timezone

# ── 1. Jalankan scraper ───────────────────────────────────────────────────────
print("🚀 Menjalankan scraper...")
from health_scraper_final import scrape_all

df = scrape_all(
    output_json     = "health_news_raw.json",
    checkpoint_every= 300,
)

if df.empty:
    print("❌ DataFrame kosong, scraping gagal. Hentikan.")
    sys.exit(1)

print(f"✅ Scraping selesai: {len(df):,} artikel")

# ── 2. Simpan CSV ─────────────────────────────────────────────────────────────
csv_path = "health_news.csv"
df.to_csv(csv_path, index=True, encoding="utf-8-sig")
print(f"💾 Tersimpan: {csv_path}")

# ── 3. Push ke Hugging Face Datasets ─────────────────────────────────────────
# HF_TOKEN diambil dari environment variable (di-set di GitHub Actions Secrets)
# HF_DATASET_REPO diambil dari env juga, format: "username/nama-dataset"
HF_TOKEN       = os.environ.get("HF_TOKEN")
HF_DATASET_REPO = os.environ.get("HF_DATASET_REPO")  # contoh: "argodinata/indonesian-health-news"

if not HF_TOKEN:
    print("❌ HF_TOKEN tidak ditemukan di environment variables.")
    sys.exit(1)

if not HF_DATASET_REPO:
    print("❌ HF_DATASET_REPO tidak ditemukan di environment variables.")
    sys.exit(1)

from huggingface_hub import HfApi

api = HfApi(token=HF_TOKEN)

# Buat repo kalau belum ada
try:
    api.create_repo(
        repo_id  = HF_DATASET_REPO,
        repo_type= "dataset",
        exist_ok = True,       # tidak error kalau sudah ada
        private  = False,      # ganti True kalau mau private
    )
    print(f"📦 Dataset repo: https://huggingface.co/datasets/{HF_DATASET_REPO}")
except Exception as e:
    print(f"⚠️  Buat repo gagal (mungkin sudah ada): {e}")

# Upload CSV
scraped_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
api.upload_file(
    path_or_fileobj = csv_path,
    path_in_repo    = "health_news.csv",
    repo_id         = HF_DATASET_REPO,
    repo_type       = "dataset",
    commit_message  = f"Auto-update scraping: {len(df):,} artikel ({scraped_at})",
)
print(f"✅ CSV berhasil di-push ke HF Datasets!")
print(f"🔗 https://huggingface.co/datasets/{HF_DATASET_REPO}")

# Upload juga JSON backup (opsional, bisa dihapus kalau mau hemat storage)
api.upload_file(
    path_or_fileobj = "health_news_raw.json",
    path_in_repo    = "health_news_raw.json",
    repo_id         = HF_DATASET_REPO,
    repo_type       = "dataset",
    commit_message  = f"Auto-update JSON backup ({scraped_at})",
)
print("✅ JSON backup juga di-push.")
